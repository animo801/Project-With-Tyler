var $form = $('form#test-form'),
    url = 'https://script.google.com/macros/s/AKfycbxok7gLaE_ftmXTbnQsAzLCLLsgRJxXOX2RXAczfx8GrO-a3Qn9/exec'

$('#submit-form').on('click', function(e) {
  e.preventDefault();
  var jqxhr = $.ajax({
    url: url,
    method: "GET",
    dataType: "json",
    data: $form.serializeObject()
  }).success(
    alert('Boom!')
  );
})

$("#submit-form").click(function() {
  $('.transform').toggleClass('custom-button-active');
    return false;
});